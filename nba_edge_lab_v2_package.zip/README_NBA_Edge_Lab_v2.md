# NBA Edge Lab v2

A separate Streamlit app for NBA game and player projections. It does not modify the NFL or NHL projects.

## Included
- ESPN schedule lookup and best-effort injury feed.
- Player-game log ingestion by CSV, with optional BALLDONTLIE API integration when the user's plan permits it.
- Rolling, recency-weighted player baselines with shrinkage toward season averages.
- Opponent-aware team score forecasts using historical team game results, when supplied.
- Monte Carlo game-score ranges and player box-score distributions.
- Player prop probabilities for points, rebounds, assists, threes, steals, blocks, turnovers, PRA, PR and PA.
- American odds conversion, no-vig comparison, overround and estimated expected value.
- Chronological team-score backtest with later holdout summary.
- CSV/JSON exports and templates.

## Run locally
```bash
python -m pip install -r requirements.txt
streamlit run nba_edge_lab_v2_app.py
```

## Deploy on Streamlit Community Cloud
1. Keep this in the existing separate `nba-edge-lab1` repository.
2. Replace the repository's `app.py` with this app file (rename `nba_edge_lab_v2_app.py` to `app.py`) and update `requirements.txt`.
3. Commit and push; Streamlit Community Cloud should redeploy.
4. Optional: add `BALLDONTLIE_API_KEY` in Streamlit Secrets only if you have an eligible plan. The app supports CSV upload without it.

## Required data
Player logs: one row per player per game, with `game_date,player,team,minutes,points,rebounds,assists`; other stat columns are optional.

Team game results: one row per completed game with `game_date,home_team,away_team,home_score,away_score`. Upload multiple seasons if available.

## Known limits
- ESPN's public schedule/injury endpoints are best-effort and can change.
- BALLDONTLIE player-game access depends on the API plan.
- The app does not claim a guaranteed live player-prop odds feed.
- Player score allocations are conditioned on the team score forecast; this is an approximation, not a possession-level model.
- The validation tab tests team-score forecast error. It does not establish betting profitability. A valid betting test needs timestamped historical sportsbook prices, realistic settlements, vig, a frozen selection rule and a held-out period.
